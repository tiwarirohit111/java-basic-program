package codingblock;

public class condition3 {

}
