package arrays;

public interface toString {

}
