package array;
import java.util.Arrays;  
public class stringarray2 {

    public static void main(String[] args) {
       String[] sa = new String[7]; 
       sa[0] = "tiwari";
       sa[1] = "rohit";
       sa[2] = "anurag";
       sa[3] = "rahul";
       sa[4] = "anurag sinha";
       sa[5] = "avinash";
       sa[6] = "anish";
       System.out.println("Original Array Elements:" + Arrays.toString(sa)); 

    }
}
