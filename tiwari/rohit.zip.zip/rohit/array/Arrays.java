package array;

public class Arrays {

    public static String toString(String[] sa) {
        return null;
    }

}
