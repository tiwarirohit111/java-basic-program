package array;

import java.util.Scanner;

public class loops3 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int a = sc.nextInt();
	int i = 1;
	
	while(i <= 10) {
		System.out.println(a*i);
	i++;
		
	}
}
}
