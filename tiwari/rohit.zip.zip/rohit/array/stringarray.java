package array;

public class stringarray {
 public static void main(String[] args) {
        int [] arr = new int[5];
        arr[0] = 32;
        arr[1] = 34;
        arr[2] = 13;
        arr[3] = 15;
        arr[4] = 24;
    //    System.out.println(arr[3]);

        for(int i = 0; i < arr.length; i++){
            System.out.println(arr[i] +"");
        }

    }
}
